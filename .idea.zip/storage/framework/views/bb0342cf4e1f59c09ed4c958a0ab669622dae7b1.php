


<?php $__env->startSection('title_doc'); ?>О нас <?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <h1>О нас</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('aside'); ?>
    ##parent-placeholder-b77cad1467608c98b4675073084c13ea3aba2ffb##
    <p>Дополнительный текст в О нас</p>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Openserver\domains\laravel.loc\resources\views/about.blade.php ENDPATH**/ ?>