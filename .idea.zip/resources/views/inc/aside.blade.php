@section('aside')
<div class="aside">
    <h4>Боковая панель</h4>
    <p>Текст боковой панели</p>
    @show
</div>
